"use client";

import { useEffect, useState } from "react";
import {
  BASE_PATH,
  buyUrl,
  DEFAULT_CONTENT,
  resolveImage,
  hashPassword,
  publishToGithub,
  type GithubSettings,
  type SiteContent,
} from "@/lib/content";

const DRAFT_KEY = "simple-draft";
const GH_KEY = "simple-github";

type Status = { kind: "ok" | "error" | "info"; text: string } | null;

function guessGithub(): GithubSettings {
  const base: GithubSettings = { repo: "", branch: "main", path: "public/content.json", token: "" };
  if (typeof window === "undefined") return base;
  const host = window.location.hostname;
  if (host.endsWith(".github.io")) {
    const owner = host.replace(".github.io", "");
    const first = window.location.pathname.split("/").filter(Boolean)[0];
    base.repo = `${owner}/${first || host}`;
  }
  try {
    const saved = localStorage.getItem(GH_KEY);
    if (saved) return { ...base, ...(JSON.parse(saved) as Partial<GithubSettings>) };
  } catch {}
  return base;
}

export default function SimpleSite() {
  const [content, setContent] = useState<SiteContent>(DEFAULT_CONTENT);
  const [loaded, setLoaded] = useState(false);
  const [editing, setEditing] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const [gh, setGh] = useState<GithubSettings>({ repo: "", branch: "main", path: "public/content.json", token: "" });
  const [newPassword, setNewPassword] = useState("");
  const [status, setStatus] = useState<Status>(null);
  const [busy, setBusy] = useState(false);
  const [sizes, setSizes] = useState<Record<string, string>>({});

  useEffect(() => {
    let cancelled = false;
    fetch(`${BASE_PATH}/content.json?t=${Date.now()}`, { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : DEFAULT_CONTENT))
      .catch(() => DEFAULT_CONTENT)
      .then((data) => {
        if (cancelled) return;
        setContent({ ...DEFAULT_CONTENT, ...(data as SiteContent) });
        setLoaded(true);
      });
    setGh(guessGithub());
    return () => {
      cancelled = true;
    };
  }, []);

  function update(patch: Partial<SiteContent>) {
    setContent((c) => {
      const next = { ...c, ...patch };
      try {
        localStorage.setItem(DRAFT_KEY, JSON.stringify(next));
      } catch {}
      return next;
    });
  }

  async function login(e: React.FormEvent) {
    e.preventDefault();
    const h = await hashPassword(password);
    if (h === content.passwordHash) {
      setEditing(true);
      setShowLogin(false);
      setPassword("");
      setLoginError("");
      try {
        const draft = localStorage.getItem(DRAFT_KEY);
        if (draft) {
          setContent({ ...content, ...(JSON.parse(draft) as SiteContent), passwordHash: content.passwordHash });
          setStatus({ kind: "info", text: "Je niet-gepubliceerde concept is hersteld." });
        }
      } catch {}
    } else {
      setLoginError("Onjuist wachtwoord.");
    }
  }

  async function changePassword() {
    if (newPassword.length < 6) {
      setStatus({ kind: "error", text: "Kies een wachtwoord van minimaal 6 tekens." });
      return;
    }
    update({ passwordHash: await hashPassword(newPassword) });
    setNewPassword("");
    setStatus({ kind: "ok", text: "Nieuw wachtwoord ingesteld. Publiceer om het op te slaan." });
  }

  async function publish() {
    if (!gh.repo || !gh.token) {
      setShowSettings(true);
      setStatus({ kind: "error", text: "Vul eerst je GitHub repository en token in." });
      return;
    }
    setBusy(true);
    setStatus({ kind: "info", text: "Publiceren naar GitHub…" });
    try {
      localStorage.setItem(GH_KEY, JSON.stringify(gh));
      await publishToGithub(content, gh);
      localStorage.removeItem(DRAFT_KEY);
      setStatus({
        kind: "ok",
        text: "Opgeslagen in GitHub! De site wordt over ± 1 minuut bijgewerkt.",
      });
    } catch (err) {
      setStatus({ kind: "error", text: err instanceof Error ? err.message : "Onbekende fout" });
    } finally {
      setBusy(false);
    }
  }

  function download() {
    const blob = new Blob([JSON.stringify(content, null, 2) + "\n"], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "content.json";
    a.click();
    URL.revokeObjectURL(a.href);
  }

  async function discardDraft() {
    localStorage.removeItem(DRAFT_KEY);
    const r = await fetch(`${BASE_PATH}/content.json?t=${Date.now()}`, { cache: "no-store" });
    if (r.ok) setContent({ ...DEFAULT_CONTENT, ...(await r.json()) });
    setStatus({ kind: "info", text: "Wijzigingen verworpen." });
  }

  // --- Bewerkbare velden ---
  const field =
    "w-full rounded-lg border border-dashed border-indigo-400 bg-indigo-50/60 px-2 py-1 outline-none focus:border-solid focus:bg-white";

  function T({
    k,
    className = "",
    multiline = false,
  }: {
    k: Exclude<keyof SiteContent, "features" | "products" | "passwordHash">;
    className?: string;
    multiline?: boolean;
  }) {
    const value = content[k] as string;
    if (!editing) return <span className={className}>{value}</span>;
    return multiline ? (
      <textarea
        className={`${field} ${className}`}
        rows={4}
        value={value}
        onChange={(e) => update({ [k]: e.target.value })}
      />
    ) : (
      <input className={`${field} ${className}`} value={value} onChange={(e) => update({ [k]: e.target.value })} />
    );
  }

  function updateFeature(id: string, patch: Partial<{ title: string; text: string }>) {
    update({ features: content.features.map((f) => (f.id === id ? { ...f, ...patch } : f)) });
  }

  function updateProduct(id: string, patch: Partial<SiteContent["products"][number]>) {
    update({ products: content.products.map((p) => (p.id === id ? { ...p, ...patch } : p)) });
  }

  return (
    <div className={`min-h-screen bg-white text-slate-900 ${editing ? "pb-28" : ""} ${loaded ? "" : "opacity-0"}`}>
      <header className="mx-auto flex max-w-5xl items-center justify-between px-6 py-6">
        <div className="text-xl font-semibold tracking-tight">
          {T({ k: "siteName" })}
        </div>
        <nav className="hidden gap-6 text-sm text-slate-600 sm:flex">
          <a href="#shop" className="hover:text-slate-900">Shop</a>
          <a href="#over" className="hover:text-slate-900">Over</a>
          <a href="#features" className="hover:text-slate-900">Voordelen</a>
          <a href="#contact" className="hover:text-slate-900">Contact</a>
        </nav>
      </header>

      <main>
        <section className="mx-auto max-w-3xl px-6 py-20 text-center sm:py-28">
          <h1 className="text-4xl font-bold tracking-tight sm:text-6xl">
            {T({ k: "heroTitle", className: editing ? "text-center text-2xl" : "" })}
          </h1>
          <p className="mt-6 text-lg text-slate-600">
            {T({ k: "heroSubtitle", multiline: true })}
          </p>
          <div className="mt-8 flex flex-col items-center gap-2">
            {editing ? (
              <>
                {T({ k: "buttonText", className: "max-w-xs text-center" })}
                {T({ k: "buttonLink", className: "max-w-xs text-center text-sm" })}
              </>
            ) : (
              <a
                href={content.buttonLink}
                className="rounded-full bg-slate-900 px-6 py-3 text-sm font-medium text-white transition hover:bg-slate-700"
              >
                {content.buttonText}
              </a>
            )}
          </div>
        </section>

        <section id="shop" className="mx-auto max-w-5xl px-6 py-20">
          <h2 className="text-center text-3xl font-semibold tracking-tight">
            {T({ k: "shopTitle", className: editing ? "text-center" : "" })}
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-center text-slate-600">
            {T({ k: "shopText", multiline: true, className: editing ? "text-center" : "" })}
          </p>
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {content.products.map((p) => {
              const size = sizes[p.id] ?? "";
              const needsSize = p.sizes.length > 0 && !size;
              return (
                <div key={p.id} className="flex flex-col overflow-hidden rounded-2xl border border-slate-200 shadow-sm">
                  <div className="relative aspect-square bg-slate-100">
                    {p.image && (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={resolveImage(p.image)} alt={p.name} className="h-full w-full object-cover" />
                    )}
                    {p.soldOut && (
                      <span className="absolute left-3 top-3 rounded-full bg-slate-900 px-3 py-1 text-xs font-medium text-white">
                        Uitverkocht
                      </span>
                    )}
                  </div>
                  {editing ? (
                    <div className="space-y-2 p-4 text-sm">
                      <input className={`${field} font-semibold`} value={p.name} placeholder="Naam" onChange={(e) => updateProduct(p.id, { name: e.target.value })} />
                      <textarea className={field} rows={2} value={p.description} placeholder="Omschrijving" onChange={(e) => updateProduct(p.id, { description: e.target.value })} />
                      <input className={field} value={p.price} placeholder="Prijs, bijv. € 24,95" onChange={(e) => updateProduct(p.id, { price: e.target.value })} />
                      <input className={field} value={p.image} placeholder="Afbeelding: /images/naam.jpg of URL" onChange={(e) => updateProduct(p.id, { image: e.target.value })} />
                      <input
                        className={field}
                        value={p.sizes.join(", ")}
                        placeholder="Maten, bijv. S, M, L, XL"
                        onChange={(e) => updateProduct(p.id, { sizes: e.target.value.split(",").map((x) => x.trim()).filter(Boolean) })}
                      />
                      <input className={field} value={p.paymentLink} placeholder="Betaallink (Stripe/Mollie/PayPal) – leeg = bestellen per e-mail" onChange={(e) => updateProduct(p.id, { paymentLink: e.target.value.trim() })} />
                      <div className="flex items-center justify-between">
                        <label className="flex items-center gap-2">
                          <input type="checkbox" checked={p.soldOut} onChange={(e) => updateProduct(p.id, { soldOut: e.target.checked })} />
                          Uitverkocht
                        </label>
                        <button onClick={() => update({ products: content.products.filter((x) => x.id !== p.id) })} className="text-xs text-red-600 hover:underline">
                          Verwijderen
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-1 flex-col p-4">
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="font-semibold">{p.name}</h3>
                        <span className="whitespace-nowrap font-medium">{p.price}</span>
                      </div>
                      <p className="mt-1 text-sm text-slate-600">{p.description}</p>
                      {p.sizes.length > 0 && (
                        <div className="mt-4 flex flex-wrap gap-2" role="group" aria-label="Kies een maat">
                          {p.sizes.map((sz) => (
                            <button
                              key={sz}
                              onClick={() => setSizes((s) => ({ ...s, [p.id]: sz }))}
                              className={`min-w-10 rounded-lg border px-3 py-1.5 text-sm transition ${
                                size === sz ? "border-slate-900 bg-slate-900 text-white" : "border-slate-300 hover:border-slate-900"
                              }`}
                            >
                              {sz}
                            </button>
                          ))}
                        </div>
                      )}
                      {p.soldOut ? (
                        <button disabled className="mt-4 rounded-full bg-slate-200 px-5 py-2.5 text-sm font-medium text-slate-500">
                          Uitverkocht
                        </button>
                      ) : needsSize ? (
                        <button disabled className="mt-4 rounded-full bg-slate-200 px-5 py-2.5 text-sm font-medium text-slate-500">
                          Kies een maat
                        </button>
                      ) : (
                        <a
                          href={buyUrl(p, size, content.email)}
                          className="mt-4 rounded-full bg-slate-900 px-5 py-2.5 text-center text-sm font-medium text-white transition hover:bg-slate-700"
                        >
                          {p.paymentLink ? "Nu kopen" : "Bestellen"}
                        </a>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
          {editing && (
            <div className="mt-6 text-center">
              <button
                onClick={() =>
                  update({
                    products: [
                      ...content.products,
                      { id: `p${Date.now()}`, name: "Nieuw t-shirt", description: "Omschrijving", price: "€ 25,00", image: "", sizes: ["S", "M", "L", "XL"], paymentLink: "", soldOut: false },
                    ],
                  })
                }
                className="rounded-full border border-indigo-400 px-4 py-2 text-sm text-indigo-700 hover:bg-indigo-50"
              >
                + Product toevoegen
              </button>
            </div>
          )}
        </section>

        <section id="over" className="bg-slate-50 py-20">
          <div className="mx-auto max-w-3xl px-6">
            <h2 className="text-3xl font-semibold tracking-tight">
              {T({ k: "aboutTitle" })}
            </h2>
            <p className="mt-4 whitespace-pre-line leading-relaxed text-slate-600">
              {T({ k: "aboutText", multiline: true })}
            </p>
          </div>
        </section>

        <section id="features" className="mx-auto max-w-5xl px-6 py-20">
          <h2 className="text-center text-3xl font-semibold tracking-tight">
            {T({ k: "featuresTitle", className: editing ? "text-center" : "" })}
          </h2>
          <div className="mt-10 grid gap-6 sm:grid-cols-3">
            {content.features.map((f) => (
              <div key={f.id} className="rounded-2xl border border-slate-200 p-6 shadow-sm">
                {editing ? (
                  <div className="space-y-2">
                    <input
                      className={`${field} font-semibold`}
                      value={f.title}
                      onChange={(e) => updateFeature(f.id, { title: e.target.value })}
                    />
                    <textarea
                      className={field}
                      rows={3}
                      value={f.text}
                      onChange={(e) => updateFeature(f.id, { text: e.target.value })}
                    />
                    <button
                      onClick={() => update({ features: content.features.filter((x) => x.id !== f.id) })}
                      className="text-xs text-red-600 hover:underline"
                    >
                      Verwijderen
                    </button>
                  </div>
                ) : (
                  <>
                    <h3 className="font-semibold">{f.title}</h3>
                    <p className="mt-2 text-sm text-slate-600">{f.text}</p>
                  </>
                )}
              </div>
            ))}
          </div>
          {editing && (
            <div className="mt-6 text-center">
              <button
                onClick={() =>
                  update({
                    features: [
                      ...content.features,
                      { id: `f${Date.now()}`, title: "Nieuw blok", text: "Beschrijving" },
                    ],
                  })
                }
                className="rounded-full border border-indigo-400 px-4 py-2 text-sm text-indigo-700 hover:bg-indigo-50"
              >
                + Blok toevoegen
              </button>
            </div>
          )}
        </section>

        <section id="contact" className="bg-slate-900 py-20 text-center text-white">
          <div className="mx-auto max-w-2xl px-6">
            <h2 className="text-3xl font-semibold tracking-tight">
              {T({ k: "contactTitle", className: editing ? "text-center text-slate-900" : "" })}
            </h2>
            <p className="mt-4 text-slate-300">
              {T({ k: "contactText", multiline: true, className: editing ? "text-slate-900" : "" })}
            </p>
            <div className="mt-6">
              {editing ? (
                T({ k: "email", className: "max-w-xs text-center text-slate-900" })
              ) : (
                <a
                  href={`mailto:${content.email}`}
                  className="inline-block rounded-full bg-white px-6 py-3 text-sm font-medium text-slate-900 hover:bg-slate-200"
                >
                  {content.email}
                </a>
              )}
            </div>
          </div>
        </section>
      </main>

      <footer className="mx-auto flex max-w-5xl flex-col items-center justify-between gap-3 px-6 py-8 text-sm text-slate-500 sm:flex-row">
        <div className="w-full sm:w-auto">
          {T({ k: "footer" })}
        </div>
        {!editing && (
          <button onClick={() => setShowLogin(true)} className="text-slate-400 hover:text-slate-700">
            Bewerken
          </button>
        )}
      </footer>

      {/* Inlogvenster */}
      {showLogin && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <form onSubmit={login} className="w-full max-w-sm space-y-4 rounded-2xl bg-white p-6 shadow-xl">
            <h2 className="text-lg font-semibold">Bewerken</h2>
            <input
              type="password"
              autoFocus
              placeholder="Wachtwoord"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 outline-none focus:border-slate-900"
            />
            {loginError && <p className="text-sm text-red-600">{loginError}</p>}
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => {
                  setShowLogin(false);
                  setLoginError("");
                }}
                className="rounded-lg px-4 py-2 text-sm text-slate-600 hover:bg-slate-100"
              >
                Annuleren
              </button>
              <button className="rounded-lg bg-slate-900 px-4 py-2 text-sm text-white hover:bg-slate-700">
                Inloggen
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Instellingen */}
      {editing && showSettings && (
        <div className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-black/50 p-4">
          <div className="w-full max-w-md space-y-5 rounded-2xl bg-white p-6 shadow-xl">
            <h2 className="text-lg font-semibold">Instellingen</h2>
            <div className="space-y-2">
              <h3 className="text-sm font-medium">GitHub-publicatie</h3>
              <input
                placeholder="gebruikersnaam/repository"
                value={gh.repo}
                onChange={(e) => setGh({ ...gh, repo: e.target.value.trim() })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
              <div className="flex gap-2">
                <input
                  placeholder="branch"
                  value={gh.branch}
                  onChange={(e) => setGh({ ...gh, branch: e.target.value.trim() })}
                  className="w-1/3 rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
                <input
                  placeholder="pad naar content.json"
                  value={gh.path}
                  onChange={(e) => setGh({ ...gh, path: e.target.value.trim() })}
                  className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>
              <input
                type="password"
                placeholder="GitHub token (fine-grained, Contents: Read & write)"
                value={gh.token}
                onChange={(e) => setGh({ ...gh, token: e.target.value.trim() })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
              <p className="text-xs text-slate-500">
                Het token wordt alleen in deze browser bewaard en alleen naar GitHub gestuurd.
              </p>
            </div>
            <div className="space-y-2">
              <h3 className="text-sm font-medium">Wachtwoord wijzigen</h3>
              <div className="flex gap-2">
                <input
                  type="password"
                  placeholder="Nieuw wachtwoord"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
                <button onClick={changePassword} className="rounded-lg bg-slate-100 px-3 py-2 text-sm hover:bg-slate-200">
                  Instellen
                </button>
              </div>
            </div>
            <div className="flex justify-end">
              <button
                onClick={() => {
                  try {
                    localStorage.setItem(GH_KEY, JSON.stringify(gh));
                  } catch {}
                  setShowSettings(false);
                }}
                className="rounded-lg bg-slate-900 px-4 py-2 text-sm text-white hover:bg-slate-700"
              >
                Sluiten
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Beheerbalk */}
      {editing && (
        <div className="fixed inset-x-0 bottom-0 z-40 border-t border-slate-200 bg-white/95 px-4 py-3 shadow-2xl backdrop-blur">
          <div className="mx-auto flex max-w-5xl flex-wrap items-center gap-2">
            <span className="mr-auto text-sm font-medium text-indigo-700">Bewerkmodus</span>
            {status && (
              <span
                className={`text-sm ${
                  status.kind === "error" ? "text-red-600" : status.kind === "ok" ? "text-green-700" : "text-slate-600"
                }`}
              >
                {status.text}
              </span>
            )}
            <button onClick={() => setShowSettings(true)} className="rounded-lg px-3 py-2 text-sm hover:bg-slate-100">
              Instellingen
            </button>
            <button onClick={download} className="rounded-lg px-3 py-2 text-sm hover:bg-slate-100">
              Download JSON
            </button>
            <button onClick={discardDraft} className="rounded-lg px-3 py-2 text-sm hover:bg-slate-100">
              Ongedaan maken
            </button>
            <button
              onClick={publish}
              disabled={busy}
              className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-500 disabled:opacity-50"
            >
              {busy ? "Bezig…" : "Publiceren"}
            </button>
            <button
              onClick={() => {
                setEditing(false);
                setStatus(null);
              }}
              className="rounded-lg border border-slate-300 px-3 py-2 text-sm hover:bg-slate-100"
            >
              Uitloggen
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
