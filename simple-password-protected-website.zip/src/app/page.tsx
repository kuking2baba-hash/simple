import SimpleSite from "@/components/SimpleSite";

export default function Home() {
  return <SimpleSite />;
}
