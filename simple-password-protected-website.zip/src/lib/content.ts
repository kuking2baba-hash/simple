export type Feature = { id: string; title: string; text: string };

export type Product = {
  id: string;
  name: string;
  description: string;
  price: string; // bijv. "€ 24,95"
  image: string; // "/images/x.jpg" (uit public/) of een volledige URL
  sizes: string[];
  paymentLink: string; // bijv. een Stripe Payment Link
  soldOut: boolean;
};

export function resolveImage(src: string): string {
  return src.startsWith("/") ? `${BASE_PATH}${src}` : src;
}

export function buyUrl(p: Product, size: string, email: string): string {
  const ref = `${p.name}${size ? "-" + size : ""}`.replace(/[^a-zA-Z0-9_-]+/g, "-").slice(0, 190);
  if (p.paymentLink) {
    try {
      const u = new URL(p.paymentLink);
      if (u.hostname.endsWith("stripe.com")) u.searchParams.set("client_reference_id", ref);
      return u.toString();
    } catch {
      return p.paymentLink;
    }
  }
  const subject = encodeURIComponent(`Bestelling: ${p.name}${size ? " (maat " + size + ")" : ""}`);
  const body = encodeURIComponent(
    `Hallo,\n\nIk wil graag bestellen:\n- ${p.name}${size ? ", maat " + size : ""} (${p.price})\n\nMijn naam en adres:\n`,
  );
  return `mailto:${email}?subject=${subject}&body=${body}`;
}

export type SiteContent = {
  shopTitle: string;
  shopText: string;
  products: Product[];
  siteName: string;
  heroTitle: string;
  heroSubtitle: string;
  buttonText: string;
  buttonLink: string;
  aboutTitle: string;
  aboutText: string;
  featuresTitle: string;
  features: Feature[];
  contactTitle: string;
  contactText: string;
  email: string;
  footer: string;
  passwordHash: string;
};

// Wachtwoord is standaard "simple" – verander dit direct in de bewerkmodus!
export const DEFAULT_CONTENT: SiteContent = {
  shopTitle: "Shop",
  shopText: "Simpele t-shirts van zacht biologisch katoen.",
  products: [],
  siteName: "simple",
  heroTitle: "Eenvoud is de ultieme verfijning.",
  heroSubtitle: "Een rustige, snelle website die je zelf bewerkt.",
  buttonText: "Neem contact op",
  buttonLink: "#contact",
  aboutTitle: "Over simple",
  aboutText: "Pas deze tekst aan in de bewerkmodus.",
  featuresTitle: "Waarom simple?",
  features: [],
  contactTitle: "Contact",
  contactText: "Stuur gerust een bericht.",
  email: "hallo@example.com",
  footer: "© simple",
  passwordHash: "2dbcdf0d5281a2e766469588206a01716d91ff45b969c7788b11fc4e70672288",
};

export const BASE_PATH = process.env.NEXT_PUBLIC_BASE_PATH || "";

export async function hashPassword(password: string): Promise<string> {
  const data = new TextEncoder().encode("simple::" + password);
  const buf = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export function toBase64Utf8(text: string): string {
  const bytes = new TextEncoder().encode(text);
  let bin = "";
  bytes.forEach((b) => (bin += String.fromCharCode(b)));
  return btoa(bin);
}

export type GithubSettings = {
  repo: string; // owner/repo
  branch: string;
  path: string;
  token: string;
};

export async function publishToGithub(
  content: SiteContent,
  gh: GithubSettings,
): Promise<void> {
  const api = `https://api.github.com/repos/${gh.repo}/contents/${gh.path}`;
  const headers = {
    Authorization: `Bearer ${gh.token}`,
    Accept: "application/vnd.github+json",
  };
  let sha: string | undefined;
  const existing = await fetch(`${api}?ref=${encodeURIComponent(gh.branch)}`, { headers });
  if (existing.ok) {
    sha = ((await existing.json()) as { sha: string }).sha;
  } else if (existing.status !== 404) {
    throw new Error(`GitHub fout (${existing.status}). Controleer repo en token.`);
  }
  const res = await fetch(api, {
    method: "PUT",
    headers,
    body: JSON.stringify({
      message: "Update content via simple editor",
      content: toBase64Utf8(JSON.stringify(content, null, 2) + "\n"),
      branch: gh.branch,
      sha,
    }),
  });
  if (!res.ok) {
    const err = (await res.json().catch(() => ({}))) as { message?: string };
    throw new Error(err.message || `Opslaan mislukt (${res.status})`);
  }
}
