# simple

Een eenvoudige website die je gratis host op **GitHub Pages** en zelf bewerkt met een **wachtwoord**.

## Hosten op GitHub Pages

1. Maak een repository op GitHub en push dit project naar de `main` branch.
2. Ga naar **Settings → Pages** en kies bij *Source*: **GitHub Actions**.
3. De workflow `.github/workflows/deploy.yml` bouwt en publiceert de site automatisch bij elke push.
   Je site staat op `https://<gebruikersnaam>.github.io/<repository>/`.

## Bewerken

1. Open je site, klik onderaan op **Bewerken** en log in. Het standaardwachtwoord is **`simple`**.
2. Wijzig meteen je wachtwoord via **Instellingen → Wachtwoord wijzigen**.
3. Pas de teksten direct op de pagina aan.
4. Maak een *fine-grained personal access token* op GitHub (Settings → Developer settings) met
   toegang tot alleen deze repository en rechten **Contents: Read and write**.
   Vul repository (`gebruikersnaam/repository`) en token in bij **Instellingen**.
5. Klik op **Publiceren**: de wijziging wordt in `public/content.json` gecommit en de site wordt
   binnen ongeveer een minuut automatisch opnieuw gepubliceerd.

Zonder token kun je ook **Download JSON** gebruiken en het bestand zelf vervangen in `public/content.json`.

## Let op: beveiliging

GitHub Pages is statisch, er is geen server. Het wachtwoord beschermt de bewerkmodus in de browser
(alleen een hash staat in `content.json`). De échte beveiliging is je GitHub-token: alleen wie
schrijfrechten op de repository heeft kan wijzigingen publiceren. Gebruik een sterk wachtwoord
en deel je token nooit.

## Lokaal draaien

```bash
npm install
npm run dev
```

## Shop (t-shirts verkopen)

Onder **Bewerken** kun je in de sectie *Shop* producten toevoegen, wijzigen en verwijderen
(naam, omschrijving, prijs, afbeelding, maten, uitverkocht).

- **Afbeeldingen**: zet een bestand in `public/images/` en vul `/images/naam.jpg` in, of gebruik een volledige URL.
- **Betalen**: maak per product een *Payment Link* in Stripe (dashboard.stripe.com → Payment Links; ook Mollie en
  PayPal-links werken) en plak die in het veld *Betaallink*. Klanten betalen dan veilig bij de betaalprovider.
  Voor Stripe wordt de gekozen maat meegestuurd als `client_reference_id` (zichtbaar bij de betaling).
  Wil je dat klanten de maat zelf in Stripe kiezen, voeg dan een dropdown "Maat" toe als aangepast veld in de Payment Link.
- **Zonder betaallink** opent de knop *Bestellen* een e-mail naar het adres in het contactblok, met product en maat ingevuld.

Een winkelmandje met meerdere producten in één betaling vereist een server en is niet mogelijk op GitHub Pages.
